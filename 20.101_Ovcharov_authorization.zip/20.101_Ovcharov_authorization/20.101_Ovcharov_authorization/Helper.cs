﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20._101_Ovcharov_authorization
{
    class Helper
    {
        private AuthorizationEntities authorizationEntities;
        public AuthorizationEntities GetContext()
        {
            if(authorizationEntities == null)
            {
                authorizationEntities = new AuthorizationEntities();
            }
            return authorizationEntities;
        }
        public Users Authorization(string login, string password)
        {
            Users user = authorizationEntities.Users.Where(x => x.Login == login && x.Password == password).FirstOrDefault();
            return user;
        }
        public string GetRole(Users user)
        {
            Roles role = authorizationEntities.Roles.Where(x => x.ID_Role == user.ID_Role).FirstOrDefault();
            return role.Name;
        }
    }
}
